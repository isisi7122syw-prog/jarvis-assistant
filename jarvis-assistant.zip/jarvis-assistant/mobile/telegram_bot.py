# mobile/telegram_bot.py
# J.A.R.V.I.S. Telefon (Telegram) Versiyonu
# Sesli mesaj + metin destekler

import asyncio
import os
import tempfile
from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    filters,
    ContextTypes,
)
from config import TELEGRAM_BOT_TOKEN, TTS_ENGINE
from brain.llm import JARVISBrain
from voice.tts import TextToSpeech
import speech_recognition as sr
from pydub import AudioSegment

# Her kullanıcı için ayrı beyin (basit oturum)
user_brains: dict[int, JARVISBrain] = {}
tts = TextToSpeech(engine=TTS_ENGINE)


def get_brain(user_id: int) -> JARVISBrain:
    if user_id not in user_brains:
        # Mobilde sistem araçları (uygulama açma vb.) kapalı
        user_brains[user_id] = JARVISBrain(enable_tools=False)
    return user_brains[user_id]


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "J.A.R.V.I.S. çevrimiçi ve emrinize amade, Efendim.\n\n"
        "Bana metin veya sesli mesaj gönderebilirsiniz.\n"
        "Komutlar:\n"
        "/start - Başlat\n"
        "/reset - Konuşma hafızasını sıfırla\n"
        "/help - Yardım"
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "J.A.R.V.I.S. Yardım\n\n"
        "• Metin mesajı yazın → size cevap vereyim\n"
        "• Sesli mesaj gönderin → sesinizi dinleyip cevap vereyim\n"
        "• /reset → hafızamı temizler\n\n"
        "Not: Telefon versiyonunda bilgisayar uygulama kontrolü kapalıdır."
    )


async def reset(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id in user_brains:
        del user_brains[user_id]
    await update.message.reply_text("Hafıza sıfırlandı Efendim. Yeniden başlıyoruz.")


async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    text = update.message.text
    brain = get_brain(user_id)

    # "Yazıyor..." göstergesi
    await context.bot.send_chat_action(chat_id=update.effective_chat.id, action="typing")

    response = brain.process(text)

    # Hem metin hem sesli cevap
    await update.message.reply_text(response)

    # Sesli cevap üret
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as f:
            audio_path = f.name
        await tts.generate_audio_file(response, audio_path)
        await update.message.reply_voice(voice=open(audio_path, "rb"))
        os.remove(audio_path)
    except Exception as e:
        print(f"TTS hatası: {e}")


async def handle_voice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    brain = get_brain(user_id)

    await context.bot.send_chat_action(chat_id=update.effective_chat.id, action="typing")

    # Ses dosyasını indir
    voice = update.message.voice
    file = await context.bot.get_file(voice.file_id)

    with tempfile.NamedTemporaryFile(delete=False, suffix=".ogg") as f:
        ogg_path = f.name
    await file.download_to_drive(ogg_path)

    # OGG → WAV dönüştür (speech_recognition için)
    try:
        audio = AudioSegment.from_ogg(ogg_path)
        wav_path = ogg_path.replace(".ogg", ".wav")
        audio.export(wav_path, format="wav")

        # STT
        recognizer = sr.Recognizer()
        with sr.AudioFile(wav_path) as source:
            audio_data = recognizer.record(source)
            try:
                text = recognizer.recognize_google(audio_data, language="tr-TR")
            except sr.UnknownValueError:
                await update.message.reply_text("Anlaşılamadı Efendim, tekrar söyler misiniz?")
                return
            except sr.RequestError:
                await update.message.reply_text("Ses tanıma servisi şu an yanıt vermiyor.")
                return

        await update.message.reply_text(f"Sizi şöyle anladım: _{text}_", parse_mode="Markdown")

        # Beyne gönder
        response = brain.process(text)
        await update.message.reply_text(response)

        # Sesli cevap
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as f:
            audio_path = f.name
        await tts.generate_audio_file(response, audio_path)
        await update.message.reply_voice(voice=open(audio_path, "rb"))
        os.remove(audio_path)

    except Exception as e:
        print(f"Voice işleme hatası: {e}")
        await update.message.reply_text("Ses işlenirken bir sorun oluştu Efendim.")
    finally:
        for path in [ogg_path, wav_path if 'wav_path' in locals() else None]:
            if path and os.path.exists(path):
                os.remove(path)


def main():
    if not TELEGRAM_BOT_TOKEN:
        print("HATA: TELEGRAM_BOT_TOKEN .env dosyasında tanımlı değil!")
        return

    print("=" * 55)
    print("  J.A.R.V.I.S. Mobile (Telegram) Edition başlatılıyor...")
    print("=" * 55)

    app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("reset", reset))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    app.add_handler(MessageHandler(filters.VOICE, handle_voice))

    print("Bot çalışıyor... Telegram'dan mesaj gönderebilirsiniz.")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
