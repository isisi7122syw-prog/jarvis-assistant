# tools/system_tools.py
import subprocess
import platform
import os

def open_application(app_name: str) -> str:
    """Belirtilen uygulamayı açar."""
    system = platform.system()
    app_name = app_name.lower().strip()

    try:
        if system == "Windows":
            mapping = {
                "chrome": "chrome",
                "google chrome": "chrome",
                "notepad": "notepad",
                "hesap makinesi": "calc",
                "calculator": "calc",
                "spotify": "spotify",
                "discord": "discord",
                "vscode": "code",
                "visual studio code": "code",
                "explorer": "explorer",
                "cmd": "cmd",
            }
            command = mapping.get(app_name, app_name)
            subprocess.Popen(command, shell=True)
            return f"{app_name} açılıyor Efendim."

        elif system == "Darwin":  # macOS
            subprocess.Popen(["open", "-a", app_name])
            return f"{app_name} açılıyor Efendim."

        else:  # Linux
            subprocess.Popen([app_name])
            return f"{app_name} açılıyor Efendim."

    except Exception as e:
        return f"Üzgünüm Efendim, {app_name} açılamadı. Hata: {str(e)}"


def close_application(app_name: str) -> str:
    """Uygulamayı kapatmaya çalışır (Windows odaklı)."""
    try:
        if platform.system() == "Windows":
            os.system(f"taskkill /f /im {app_name}.exe")
            return f"{app_name} kapatıldı Efendim."
        else:
            return "Bu özellik şu an yalnızca Windows'ta destekleniyor Efendim."
    except Exception as e:
        return f"Kapatma işlemi başarısız: {str(e)}"
