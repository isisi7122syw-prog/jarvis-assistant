# tools/messaging.py
import pywhatkit as kit
import datetime

def send_whatsapp_message(phone_number: str, message: str) -> str:
    """
    WhatsApp Web üzerinden mesaj gönderir.
    phone_number: Ülke koduyla birlikte (örnek: +905551234567)
    """
    try:
        now = datetime.datetime.now()
        hour = now.hour
        minute = now.minute + 1
        if minute >= 60:
            minute = 0
            hour = (hour + 1) % 24

        kit.sendwhatmsg(
            phone_number, 
            message, 
            hour, 
            minute, 
            wait_time=15, 
            tab_close=True,
            close_time=3
        )
        return f"Mesaj {phone_number} numarasına gönderilmek üzere hazırlandı Efendim."
    except Exception as e:
        return f"WhatsApp mesajı gönderilemedi: {str(e)}"
