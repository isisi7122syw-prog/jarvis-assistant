# voice/stt.py
import speech_recognition as sr

class SpeechToText:
    def __init__(self):
        self.recognizer = sr.Recognizer()
        self.microphone = sr.Microphone()

        # Ortam gürültüsünü kalibre et
        with self.microphone as source:
            print("Kalibrasyon yapılıyor... Lütfen sessiz olun.")
            self.recognizer.adjust_for_ambient_noise(source, duration=1)
            print("Kalibrasyon tamamlandı.")

    def listen(self, timeout=8, phrase_time_limit=12) -> str | None:
        """Mikrofondan dinler ve metne çevirir."""
        with self.microphone as source:
            print("Dinliyorum Efendim...")
            try:
                audio = self.recognizer.listen(
                    source,
                    timeout=timeout,
                    phrase_time_limit=phrase_time_limit
                )
            except sr.WaitTimeoutError:
                return None

        try:
            text = self.recognizer.recognize_google(audio, language="tr-TR")
            print(f"Siz: {text}")
            return text
        except sr.UnknownValueError:
            print("Anlaşılamadı.")
            return None
        except sr.RequestError as e:
            print(f"STT hatası: {e}")
            return None
