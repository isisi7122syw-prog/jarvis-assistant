# brain/llm.py
from openai import OpenAI
from config import OPENAI_API_KEY, SYSTEM_PROMPT
from tools.system_tools import open_application, close_application
from tools.messaging import send_whatsapp_message
import json

client = OpenAI(api_key=OPENAI_API_KEY)

# OpenAI Function Calling şemaları
tools = [
    {
        "type": "function",
        "function": {
            "name": "open_application",
            "description": "Bilgisayardaki bir uygulamayı açar (Chrome, Spotify, Notepad vb.)",
            "parameters": {
                "type": "object",
                "properties": {
                    "app_name": {
                        "type": "string",
                        "description": "Açılacak uygulamanın adı"
                    }
                },
                "required": ["app_name"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "close_application",
            "description": "Çalışan bir uygulamayı kapatır",
            "parameters": {
                "type": "object",
                "properties": {
                    "app_name": {
                        "type": "string",
                        "description": "Kapatılacak uygulamanın adı (örn: chrome, notepad)"
                    }
                },
                "required": ["app_name"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "send_whatsapp_message",
            "description": "Belirtilen telefon numarasına WhatsApp mesajı gönderir",
            "parameters": {
                "type": "object",
                "properties": {
                    "phone_number": {
                        "type": "string",
                        "description": "Ülke koduyla birlikte telefon numarası (örn: +905551234567)"
                    },
                    "message": {
                        "type": "string",
                        "description": "Gönderilecek mesaj metni"
                    }
                },
                "required": ["phone_number", "message"]
            }
        }
    }
]

available_functions = {
    "open_application": open_application,
    "close_application": close_application,
    "send_whatsapp_message": send_whatsapp_message,
}


class JARVISBrain:
    def __init__(self, enable_tools: bool = True):
        self.messages = [
            {"role": "system", "content": SYSTEM_PROMPT}
        ]
        self.enable_tools = enable_tools

    def process(self, user_input: str) -> str:
        self.messages.append({"role": "user", "content": user_input})

        kwargs = {
            "model": "gpt-4o",
            "messages": self.messages,
            "temperature": 0.7,
            "max_tokens": 350
        }

        if self.enable_tools:
            kwargs["tools"] = tools
            kwargs["tool_choice"] = "auto"

        response = client.chat.completions.create(**kwargs)
        response_message = response.choices[0].message
        tool_calls = response_message.tool_calls

        if tool_calls and self.enable_tools:
            self.messages.append(response_message)

            for tool_call in tool_calls:
                function_name = tool_call.function.name
                function_args = json.loads(tool_call.function.arguments)

                print(f"[Tool] {function_name} çağrıldı → {function_args}")

                function_to_call = available_functions.get(function_name)
                if function_to_call:
                    function_response = function_to_call(**function_args)
                else:
                    function_response = "Bu fonksiyon şu an kullanılamıyor."

                self.messages.append({
                    "role": "tool",
                    "tool_call_id": tool_call.id,
                    "name": function_name,
                    "content": function_response
                })

            second_response = client.chat.completions.create(
                model="gpt-4o",
                messages=self.messages,
                temperature=0.7,
                max_tokens=250
            )
            final_content = second_response.choices[0].message.content
        else:
            final_content = response_message.content

        self.messages.append({"role": "assistant", "content": final_content})
        return final_content
