# voice/tts.py
import edge_tts
import asyncio
import os
from pydub import AudioSegment
from pydub.playback import play
import tempfile

class TextToSpeech:
    def __init__(self, engine: str = "edge"):
        self.engine = engine
        # İngiliz aksanlı, tok erkek ses (JARVIS'e yakın)
        self.voice = "en-GB-RyanNeural"   # Alternatif: en-GB-ThomasNeural

    async def _speak_edge(self, text: str):
        communicate = edge_tts.Communicate(text, self.voice)
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as f:
            temp_path = f.name
        await communicate.save(temp_path)

        audio = AudioSegment.from_mp3(temp_path)
        play(audio)
        os.remove(temp_path)

    def speak(self, text: str):
        """Metni seslendirir (senkron wrapper)."""
        if not text:
            return
        print(f"J.A.R.V.I.S.: {text}")
        asyncio.run(self._speak_edge(text))

    async def generate_audio_file(self, text: str, output_path: str = "response.mp3") -> str:
        """Ses dosyası üretir (Telegram için)."""
        communicate = edge_tts.Communicate(text, self.voice)
        await communicate.save(output_path)
        return output_path
