# J.A.R.V.I.S. - Just A Rather Very Intelligent System

Tam teşekküllü sesli yapay zeka asistanı.  
**Masaüstü (Desktop)** + **Telefon (Telegram)** versiyonları dahildir.

---

## Özellikler

### Masaüstü Versiyonu
- Mikrofon ile gerçek zamanlı sesli komut
- GPT-4o + Function Calling
- Uygulama açma / kapatma
- WhatsApp mesajı gönderme
- İngiliz aksanlı TTS (edge-tts)

### Telefon Versiyonu (Telegram Bot)
- Metin ve **sesli mesaj** desteği
- Sesli cevap (voice message)
- Konuşma hafızası (kullanıcı bazlı)
- Her yerden erişim (iOS / Android)

---

## Kurulum

### 1. Repoyu klonla
```bash
git clone https://github.com/KULLANICI_ADIN/jarvis-assistant.git
cd jarvis-assistant
```

### 2. Sanal ortam oluştur
```bash
python -m venv venv

# Windows
venv\Scripts\activate

# macOS / Linux
source venv/bin/activate
```

### 3. Bağımlılıkları kur
```bash
pip install -r requirements.txt
```

**Windows'ta PyAudio sorunu yaşarsan:**
```bash
pip install pipwin
pipwin install pyaudio
```

### 4. API Anahtarlarını ayarla
`.env.example` dosyasını kopyala:
```bash
cp .env.example .env
```

`.env` dosyasını düzenle:
```env
OPENAI_API_KEY=sk-proj-xxxxxxxxxxxxxxxx
TELEGRAM_BOT_TOKEN=123456:ABC-DEF...   # Sadece telefon versiyonu için
```

---

## Çalıştırma

### Masaüstü Versiyonu
```bash
python main.py
```

### Telefon (Telegram) Versiyonu
1. [@BotFather](https://t.me/BotFather) ile yeni bot oluştur
2. Token'ı `.env` dosyasına yaz
3. Çalıştır:
```bash
python mobile/telegram_bot.py
```

Artık Telegram'dan botuna yazabilir veya sesli mesaj gönderebilirsin.

---

## Klasör Yapısı

```
jarvis-assistant/
├── main.py                 # Masaüstü ana dosya
├── config.py               # Ayarlar + Sistem Prompt
├── requirements.txt
├── .env.example
├── voice/
│   ├── stt.py              # Speech-to-Text
│   └── tts.py              # Text-to-Speech
├── tools/
│   ├── system_tools.py     # Uygulama aç/kapa
│   └── messaging.py        # WhatsApp
├── brain/
│   └── llm.py              # GPT-4o + Function Calling
└── mobile/
    └── telegram_bot.py     # Telefon versiyonu
```

---

## Kullanım Örnekleri (Masaüstü)

| Sen                                  | J.A.R.V.I.S.                          |
|--------------------------------------|---------------------------------------|
| "Chrome'u aç"                        | Uygulamayı açar                       |
| "Spotify'ı kapat"                    | Uygulamayı kapatır                    |
| "Ahmet'e WhatsApp'tan mesaj at..."   | pywhatkit ile mesaj planlar           |
| "Bugün nasılsın?"                    | Kısa ve kibar cevap verir             |

---

## Notlar

- İlk WhatsApp kullanımında tarayıcı açılır ve QR ile giriş yapmanız gerekir.
- Telegram versiyonunda bilgisayar kontrolü (uygulama açma) bilinçli olarak kapalıdır.
- edge-tts ücretsizdir ve İngiliz aksanı oldukça iyidir.
- ElevenLabs entegrasyonu istersen ekleyebilirsin.

---

## Lisans

MIT
