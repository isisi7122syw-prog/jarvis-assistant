# main.py - Masaüstü (Desktop) Versiyonu
from voice.stt import SpeechToText
from voice.tts import TextToSpeech
from brain.llm import JARVISBrain
from config import TTS_ENGINE
import sys

def main():
    print("=" * 55)
    print("  J.A.R.V.I.S. Desktop Edition başlatılıyor...")
    print("=" * 55)

    try:
        stt = SpeechToText()
        tts = TextToSpeech(engine=TTS_ENGINE)
        brain = JARVISBrain(enable_tools=True)
    except Exception as e:
        print(f"Başlatma hatası: {e}")
        print("Lütfen mikrofon izinlerini ve .env dosyasını kontrol edin.")
        sys.exit(1)

    tts.speak("J.A.R.V.I.S. çevrimiçi ve emrinize amade, Efendim.")

    while True:
        try:
            user_text = stt.listen()

            if user_text is None:
                continue

            # Çıkış komutları
            lower = user_text.lower()
            if any(word in lower for word in ["kapat", "çıkış", "görüşürüz", "uyku modu", "sistemi kapat"]):
                tts.speak("Anlaşıldı Efendim. Sistem kapatılıyor. İyi günler.")
                break

            # LLM'e gönder
            response = brain.process(user_text)

            # Seslendir
            tts.speak(response)

        except KeyboardInterrupt:
            tts.speak("Sistem manuel olarak kapatıldı. Görüşmek üzere Efendim.")
            break
        except Exception as e:
            print(f"Hata: {e}")
            tts.speak("Bir sorun oluştu Efendim. Tekrar deniyorum.")


if __name__ == "__main__":
    main()
